export interface ITableau {
    idTableau: number;
    libelle:   string;
    sections:  any[];
    fiches:    any[];
}