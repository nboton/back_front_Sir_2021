export interface ISection {
    idSection:            number;
    libelle:              string;
    tableaux:             any[];
    positionnementFiches: any[];
}
