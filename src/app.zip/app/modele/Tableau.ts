import { ITableau } from "./ITableau";
import { IUser } from "./IUser";

export class Tableau {
   
    constructor(  
        idTableau: number,
        libelle:   string,
        sections:  any[],
        fiches:    any[]
        ){

    }
  }